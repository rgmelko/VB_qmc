#ifndef header
#define header

#include<iostream>
#include<fstream>
#include<math.h>
#include"mtrand.h"
#include<iomanip>
using namespace std;

#endif
